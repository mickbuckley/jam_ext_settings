<?php
/**
* English language file for Jam IFrame Tab extension
*
* Author: Mick Buckley.
* Copyright (c) Jam Digital Ltd. 2009 Some Rights Reserved.
* Creative Commons Attribution-Share Alike New Zealand.
*
* Visit http://creativecommons.org/licenses/by-sa/3.0/nz/ for details.
*
*/

$L = array(

'weblogs'=>'Enable Extension On The Following Weblogs',
'iframe_target'=>'Web Page to Display in IFrame',
'Jam_iframe_tab'=>'IFrame Tab',
// END
''=>''
);
?>
