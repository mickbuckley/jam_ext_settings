<?php
/**
* English language file for Jam Ext Settings extension
*
* Author: Mick Buckley.
* Copyright (c) Jam Digital Ltd. 2009 Some Rights Reserved.
* Creative Commons Attribution-Share Alike New Zealand.
*
* Visit http://creativecommons.org/licenses/by-sa/3.0/nz/ for details.
*
*/

$L = array(

'Jam_ext_settings'=>'Jam Ext Settings',
'setting_one'=>'Setting One',
// END
''=>''
);
?>
